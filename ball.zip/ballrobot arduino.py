import pygame
from keras.models import load_model
import cv2
import numpy as np
import time
import serial

# Disable scientific notation for clarity
np.set_printoptions(suppress=True)

# Load the model
model = load_model("keras_Model.h5", compile=False)

# Load the labels
class_names = open("labels.txt", "r").readlines()

# Initialize Pygame
pygame.init()

# Load MP3 files
white_sound = pygame.mixer.Sound("White.mp3")
yellow_sound = pygame.mixer.Sound("Yellow.mp3")

ser = serial.Serial('COM20', 9600)

# CAMERA can be 0 or 1 based on default camera of your computer
camera = cv2.VideoCapture(1)

# Variables to track whether sounds have been played and detection time
is_sound_playing = False
start_time = None
current_sound = None

while True:
    # Grab the webcamera's image.
    ret, image = camera.read()

    # Resize the raw image into (224-height,224-width) pixels
    image = cv2.resize(image, (224, 224), interpolation=cv2.INTER_AREA)

    # Make a copy of the image for overlaying text
    overlay = image.copy()

    # Make the image a numpy array and reshape it to the model's input shape.
    image_input = np.asarray(image, dtype=np.float32).reshape(1, 224, 224, 3)

    # Normalize the image array
    image_input = (image_input / 127.5) - 1

    # Predicts the model
    prediction = model.predict(image_input, verbose=0)
    index = np.argmax(prediction)
    class_name = class_names[index]
    confidence_score = prediction[0][index]

    if "White" in class_name:
        cv2.putText(overlay, "White", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        if not is_sound_playing:
            if start_time is None:
                start_time = time.time()
            elif time.time() - start_time >= 1.3:
                current_sound = white_sound
                current_sound.play()
                is_sound_playing = True
                ser.write(b'w')
    elif "Yellow" in class_name:
        cv2.putText(overlay, "Yellow", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
        if not is_sound_playing:
            if start_time is None:
                start_time = time.time()
            elif time.time() - start_time >= 1.35:
                current_sound = yellow_sound
                current_sound.play()
                is_sound_playing = True
                ser.write(b'y')
    else:
        cv2.putText(overlay, "None", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        start_time = None
        if is_sound_playing:
            current_sound.stop()
            is_sound_playing = False

    confidence_text = "Confidence: {:.2f}%".format(confidence_score * 100)
    cv2.putText(overlay, confidence_text, (10, image.shape[0] - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

    image = cv2.addWeighted(overlay, 0.5, image, 0.5, 0)

    cv2.imshow("Webcam Image", image)

    keyboard_input = cv2.waitKey(1)

    if keyboard_input == 27:
        break

camera.release()
cv2.destroyAllWindows()
